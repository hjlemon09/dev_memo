package com.example.product;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    public record Product(long id, String name, String category, int price, String summary, String description, String icon) {}
    private final List<Product> products = List.of(
        new Product(1, "무선 헤드폰", "오디오", 129000, "음악에 집중하는 나만의 시간", "노이즈 캔슬링과 편안한 쿠션을 갖춘 무선 헤드폰입니다. 최대 30시간 재생하며 USB-C로 충전합니다.", "🎧"),
        new Product(2, "기계식 키보드", "컴퓨터", 89000, "매일의 작업을 더 즐겁게", "조용한 스위치와 견고한 프레임을 갖춘 키보드입니다. 유선 USB 연결과 한글 키캡을 지원합니다.", "⌨️"),
        new Product(3, "데스크 램프", "라이프스타일", 45000, "책상 위를 채우는 따뜻한 빛", "밝기와 색온도를 조절할 수 있는 LED 램프입니다. 독서와 작업에 맞게 조명을 설정할 수 있습니다.", "💡"),
        new Product(4, "휴대용 스피커", "오디오", 69000, "좋아하는 음악을 어디서나", "가벼운 블루투스 스피커입니다. 최대 12시간 재생하며 생활 방수를 지원합니다.", "🔊")
    );
    @GetMapping public List<Product> list() { return products; }
    @GetMapping("/{id}") public Product detail(@PathVariable long id) {
        return products.stream().filter(p -> p.id() == id).findFirst()
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "제품을 찾을 수 없습니다."));
    }
}
