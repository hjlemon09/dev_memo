package com.example.product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class ProductApiApplicationTests {
    private MockMvc mvc;
    @BeforeEach void setup() { mvc = MockMvcBuilders.standaloneSetup(new ProductController()).build(); }
    @Test void listsSeedProducts() throws Exception {
        mvc.perform(get("/api/products")).andExpect(status().isOk())
            .andExpect(jsonPath("$.length()").value(4))
            .andExpect(jsonPath("$[0].name").value("무선 헤드폰"));
    }
    @Test void returnsSelectedProduct() throws Exception {
        mvc.perform(get("/api/products/1")).andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(1))
            .andExpect(jsonPath("$.price").value(129000));
    }
    @Test void missingProductReturns404() throws Exception {
        mvc.perform(get("/api/products/999")).andExpect(status().isNotFound());
    }
    @Test void invalidIdReturns400() throws Exception {
        mvc.perform(get("/api/products/invalid")).andExpect(status().isBadRequest());
    }
}
