@echo off
cd /d "%~dp0backend"
if exist "target\product-api-0.0.1-SNAPSHOT.jar" (
  java -jar "target\product-api-0.0.1-SNAPSHOT.jar"
) else (
  call mvnw.cmd spring-boot:run
)
pause
