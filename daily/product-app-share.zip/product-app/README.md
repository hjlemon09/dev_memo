# Product Room

JDK 21 / Spring Boot 4.1.1 / Angular 21.2 / Node.js 24 LTS

## IntelliJ에서 실행

1. IntelliJ의 Open에서 backend/pom.xml을 열고 Maven 프로젝트로 불러옵니다.
2. Project SDK와 Maven Runner JRE를 JDK 21로 지정합니다.
3. com.example.product.ProductApiApplication의 main을 실행합니다.
4. 프론트엔드는 frontend 폴더에서 npm.cmd start를 실행합니다.
5. http://localhost:4200 에서 제품을 클릭하면 상세 화면으로 이동합니다.

IntelliJ Community에서도 Java main으로 백엔드를 실행할 수 있습니다.

## 터미널 실행

백엔드 (backend 폴더):
    .\mvnw.cmd spring-boot:run

프론트엔드 (frontend 폴더, 별도 터미널):
    npm.cmd ci
    npm.cmd start

백엔드: http://localhost:8080
프론트엔드: http://localhost:4200

## API

- GET /api/products : 제품 목록
- GET /api/products/1 : 제품 상세
- 존재하지 않는 제품: HTTP 404
- 숫자가 아닌 ID: HTTP 400

제품 4개를 서버 메모리에 보관합니다. DB 설정은 필요하지 않습니다.
샘플 데이터는 backend/src/main/java/com/example/product/ProductController.java에서 수정합니다.
Angular 개발 서버의 프록시가 /api 요청을 백엔드에 전달합니다.
개발 서버를 종료하려면 해당 터미널에서 Ctrl+C를 누르세요.

## 검증

백엔드: .\mvnw.cmd test
프론트엔드: npm.cmd run build

Angular의 build 결과는 frontend/dist/frontend/browser에 생성됩니다.
별도로 배포하려면 정적 서버에서 SPA 경로 fallback과 /api 프록시를 설정해야 합니다.

검증 결과: API MockMvc 테스트 4개 통과, Angular production 빌드 통과.
Codex 브라우저 도구에서 로컬 주소 접속이 타임아웃되어 실제 브라우저 클릭 검증은 완료하지 못했습니다.
