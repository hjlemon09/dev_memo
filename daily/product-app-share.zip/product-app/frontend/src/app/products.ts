import { Component, Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AsyncPipe, DecimalPipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, map, of, startWith, switchMap } from 'rxjs';
interface Product {
  id: number; name: string; category: string; price: number;
  summary: string; description: string; icon: string;
}
type State<T> = { loading: boolean; data: T | null; error: string };
function ready<T>(data: T): State<T> { return { loading: false, data, error: '' }; }
function failure<T>(error: HttpErrorResponse): State<T> {
  return { loading: false, data: null, error: error.status === 404 ? '제품을 찾을 수 없습니다.' : '제품 정보를 불러오지 못했습니다. 다시 시도해 주세요.' };
}
@Injectable({ providedIn: 'root' })
export class Products {
  private http = inject(HttpClient);
  list() { return this.http.get<Product[]>('/api/products'); }
  detail(id: string) { return this.http.get<Product>('/api/products/' + encodeURIComponent(id)); }
}
@Component({
  imports: [AsyncPipe, DecimalPipe, RouterLink],
  template: `
    <section class="intro"><span class="eyebrow">CURATED FOR YOUR EVERYDAY</span><h1>일상을 더 좋게 만드는<br>작은 발견.</h1><p>당신의 책상과 하루에 어울리는 제품을 만나보세요.</p></section>
    @if (state$ | async; as state) {
      @if (state.loading) { <p role="status">제품을 불러오는 중입니다…</p> }
      @if (state.error) { <div class="message" role="alert">{{ state.error }} <button (click)="reload()">다시 시도</button></div> }
      @if (state.data; as products) {
        <div class="section-title"><h2>모든 제품</h2><span>{{ products.length }}개의 제품</span></div>
        <section class="grid">
          @for (product of products; track product.id) {
            <a class="card" [routerLink]="['/products', product.id]">
              <div class="art" aria-hidden="true">{{ product.icon }}</div>
              <div class="card-body"><span class="category">{{ product.category }}</span><h3>{{ product.name }}</h3><p>{{ product.summary }}</p><div class="card-bottom"><strong>₩{{ product.price | number }}</strong><span>상세 보기 ↗</span></div></div>
            </a>
          } @empty { <p>등록된 제품이 없습니다.</p> }
        </section>
      }
    }`
})
export class ProductList {
  private products = inject(Products);
  state$ = this.load();
  private load() { return this.products.list().pipe(map(ready), catchError(e => of(failure<Product[]>(e))), startWith({ loading: true, data: null, error: '' } as State<Product[]>)); }
  reload() { this.state$ = this.load(); }
}
@Component({
  imports: [AsyncPipe, DecimalPipe, RouterLink],
  template: `
    <a routerLink="/" class="back">← 제품 목록</a>
    @if (state$ | async; as state) {
      @if (state.loading) { <p role="status">제품을 불러오는 중입니다…</p> }
      @if (state.error) { <div class="message" role="alert">{{ state.error }} <button (click)="reload()">다시 시도</button></div> }
      @if (state.data; as product) {
        <section class="detail"><div class="art detail-art" aria-hidden="true">{{ product.icon }}</div><div><span class="category">{{ product.category }}</span><h1>{{ product.name }}</h1><p class="summary">{{ product.summary }}</p><strong class="price">₩{{ product.price | number }}</strong><hr><h2>제품 소개</h2><p class="description">{{ product.description }}</p><a routerLink="/" class="button">다른 제품 둘러보기 →</a></div></section>
      }
    }`
})
export class ProductDetail {
  private route = inject(ActivatedRoute);
  private products = inject(Products);
  state$ = this.load();
  private load() { return this.route.paramMap.pipe(switchMap(params => this.products.detail(params.get('id') ?? '').pipe(map(ready), catchError(e => of(failure<Product>(e))), startWith({ loading: true, data: null, error: '' } as State<Product>)))); }
  reload() { this.state$ = this.load(); }
}
