import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
@Component({
  selector: 'app-root', imports: [RouterLink, RouterOutlet],
  template: '<header><a routerLink="/" class="brand">◈ PRODUCT ROOM</a><span>일상을 위한 작은 발견</span></header><main><router-outlet /></main><footer>PRODUCT ROOM · 제품 카탈로그</footer>'
})
export class App {}
