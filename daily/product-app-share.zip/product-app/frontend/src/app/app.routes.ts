import { Routes } from '@angular/router';
import { ProductList, ProductDetail } from './products';
export const routes: Routes = [
  { path: '', component: ProductList, title: '제품 목록 | Product Room' },
  { path: 'products/:id', component: ProductDetail, title: '제품 상세 | Product Room' },
  { path: '**', redirectTo: '' }
];
