@echo off
cd /d "%~dp0"
start "Product API" cmd /k call "%~dp0start-backend.cmd"
start "Angular" cmd /k call "%~dp0start-frontend.cmd"
